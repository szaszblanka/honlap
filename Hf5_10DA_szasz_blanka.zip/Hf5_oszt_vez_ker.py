print()
t = list(map(lambda x: list(map(int, x.split(":"))),open("input.txt").read().split("\n")))
#print(t)

print("2. feladat")

t20 = list(filter(lambda x: x/2 == int(x/2),t[0]))
#print(t20)
print(f'Az 1. sorban szereplő párosszámok minimuma: {min(t20)}')
print()

print("3. feladat")

#t30= list(lambda x, y: x * y, filter(lambda x: x>5, t[1]), 1)
t30=list(map(lambda x : x**2,t[1]))
#print(t[1])
#print(t30)
print(f'A 2. sorban szereplő számok négyzeteinek összege: {sum(t30)}')
print()

print("4. feladat")
#print(t[2])
from functools import reduce
t40 = reduce(lambda x, y: x * y, filter(lambda x: x/2 != int(x/2), t[2]), 1)
#t40 = list(filter(lambda x: ,t[2]))
#t41 = list(lambda x,y : x*y,t40)
#print(t40)
#print(t41)
print(f'A 3. sorban szereplő páratlan számok szorzatának nagyságrendje: 10^{len(str(t40))} ')
print( )

print("5. feladat")
#print(t[3])
#t50 = list(filter(lambda x: x/2 != int(x/2),t[3]))

t50 = list(sorted(t[3])[-10:])
#print(t50)
print(f'A 4. sorban szereplő 10 legnagyobb szám összege: {sum(t50)} ')
print()
# ...
print("6. feladat")
from math import sqrt as gy
#print(t[4])
#t60=list(filter(lambda x: x<15,t[4]))
t60=sorted(list(filter(lambda x: gy(x) == int(gy(x)),t[4])))
#print(t60)
print(f'Az 5. sorban szereplő négyzetszámok számtani közepe: {sum(t60)/len(t60):0.2f}')

print()
print("7. feladat")
t70=list(filter(lambda x: x>14,sum(t, [])))
#print(t70)
print(f'Az inputban szereplő összes szám közül a 14-nél nagyobb számok maximuma: {max(t70)}')
